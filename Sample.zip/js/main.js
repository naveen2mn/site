//(function() {

var data = ['Apple', 'Orange', 'Grape'];

var template = '<li class="list-group-item">{{data[i]}}</li>';

$.fn.render = function (data, template) {
    var _self = this;
    function EventedArray(handler) {
        this.stack = [];
        this.mutationHandler = handler || function () { };
        this.setHandler = function (f) {
            this.mutationHandler = f;
        };
        this.callHandler = function () {
            if (typeof this.mutationHandler === 'function') {
                this.mutationHandler();
            }
        };
        this.push = function (obj) {
            console.log('Not comming');
            this.stack.push(obj);
            this.callHandler();
        };
        this.pop = function () {
            this.stack.pop();
            this.callHandler();
            return this;
        };
        this.getArray = function () {
            return this.stack;
        }
    }

    var renderer = function () {
        _self.empty();
        arr.getArray().forEach(function (ele) {
            _self.append('<li class="list-group-item">' +ele+ '</li>');
        })
    };

    var arr = new EventedArray(renderer);
    return arr;
}


var myarr = $('#list').render(data, template);
    function add(){
        myarr.push($('#name').val());
    }
    





